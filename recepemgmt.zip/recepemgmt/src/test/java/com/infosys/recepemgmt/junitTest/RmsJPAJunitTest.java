package com.infosys.recepemgmt.junitTest;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.infosys.recepemgmt.bean.Ingredients;
import com.infosys.recepemgmt.bean.Recepes;
import com.infosys.recepemgmt.controller.RecepesManagementAPIController;
import com.infosys.recepemgmt.service.RecepesMgmtControllerService;

import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RmsJPAJunitTest {

	@Autowired
	RecepesMgmtControllerService recepesMgmtControllerService;

	@Autowired
	RecepesManagementAPIController recepesManagementAPIController;

	@Test
	public void getRecepe() {
		// Given
		Recepes recepe = new Recepes();
		recepe.setRecepieName("DOSA");
		recepe.setCookingIntructions("No");
		recepe.setRecepieCreationDate(new Date());
		recepe.setSurvingPeople("100");
		// when
		recepesMgmtControllerService.save(recepe);
		// when
		Recepes recepedata = recepesMgmtControllerService.findById(recepe.getRecepieId());
		// then
		assertNotNull(recepedata);
	}

	@Test
	public void getRecepeAll() {
		// Given
		Recepes recepe = new Recepes();
		recepe.setRecepieName("DOSA");
		recepe.setCookingIntructions("No");
		recepe.setRecepieCreationDate(new Date());
		recepe.setSurvingPeople("100");
		// when
		recepesMgmtControllerService.save(recepe);
		// when
		List<Recepes> recepedata = recepesMgmtControllerService.findAll();
		// then
		assertNotNull(recepedata);
	}

	@Test
	public void createRecepe() {
		// Given
		Recepes recepe = new Recepes();
		recepe.setRecepieName("DOSA");
		recepe.setCookingIntructions("No");
		recepe.setRecepieCreationDate(new Date());
		recepe.setSurvingPeople("100");
		// when
		recepesMgmtControllerService.save(recepe);
		// then
		assertNotNull(recepesMgmtControllerService.findAll());
	}

	@Test
	public void updateRecepe() {
		// Given
		Recepes recepebase = new Recepes();
		recepebase.setRecepieName("DOSA");
		recepebase.setCookingIntructions("No");
		recepebase.setRecepieCreationDate(new Date());
		recepebase.setSurvingPeople("100");
		recepesMgmtControllerService.save(recepebase);

		Recepes recepe = recepesMgmtControllerService.findById(recepebase.getRecepieId());
		recepe.setRecepieName("VISH1");
		// when
		recepesMgmtControllerService.save(recepe);
		// then
		assertNotEquals("VISH", recepesMgmtControllerService.findById(recepebase.getRecepieId()).getRecepieName());
	}

	@Test
	public void deleteRecepe() {
		// Given
		Recepes recepebase = new Recepes();
		recepebase.setRecepieName("DOSA");
		recepebase.setCookingIntructions("No");
		recepebase.setRecepieCreationDate(new Date());
		recepebase.setSurvingPeople("100");
		recepesMgmtControllerService.save(recepebase);

		// when
		recepesMgmtControllerService.deleteById(recepebase.getRecepieId());

		// then
		assertThat(recepebase.getRecepieName()).isEqualTo("DOSA");
	}

	@Test
	public void testSaveNewRecepe() {
		// Given
		Recepes recepe = new Recepes();
		recepe.setRecepieName("DOSA");
		recepe.setCookingIntructions("No");
		recepe.setRecepieCreationDate(new Date());
		recepe.setSurvingPeople("100");
		// when
		recepesMgmtControllerService.save(recepe);
		// then
		assertThat(recepe.getRecepieName()).isEqualTo("DOSA");
	}

	@Test
	public void getIngredients() {
		// Given
		Recepes recepe = new Recepes();
		recepe.setRecepieName("DOSA");
		recepe.setCookingIntructions("No");
		recepe.setRecepieCreationDate(new Date());
		recepe.setSurvingPeople("100");
		Ingredients ingredients = new Ingredients();
		ingredients.setIngredents("CHATANI");
		List<Ingredients> indreIngredientsList = singletonList(ingredients);
		recepe.setRecIngredients(indreIngredientsList);
		// when
		recepesMgmtControllerService.save(recepe);
		// when
		List<Ingredients> indreIngredientsListFinal = null;
		Recepes recepedata = recepesMgmtControllerService.findById(recepe.getRecepieId());
		if (null != recepedata) {
			indreIngredientsListFinal = recepedata.getRecIngredients();
		}
		// then
		assertNotNull(indreIngredientsListFinal);
	}

	@Test
	public void getRecepeingredientsAll() {
		// Given
		Recepes recepe = new Recepes();
		recepe.setRecepieName("DOSA");
		recepe.setCookingIntructions("No");
		recepe.setRecepieCreationDate(new Date());
		recepe.setSurvingPeople("100");
		Ingredients ingredients = new Ingredients();
		ingredients.setIngredents("CHATANI");
		List<Ingredients> indreIngredientsList = singletonList(ingredients);
		recepe.setRecIngredients(indreIngredientsList);
		// when
		recepesMgmtControllerService.save(recepe);
		// when
		List<Recepes> recepedata = recepesMgmtControllerService.findAll();
		List<Ingredients> indreIngredientsListFinal = null;
		if (null != recepedata) {
			for (Recepes rec : recepedata) {
				indreIngredientsListFinal = rec.getRecIngredients();
			}

		}
		// then
		assertNotNull(indreIngredientsListFinal);
	}

	@Test
	public void createRecepeIngredients() {
		// Given
		Recepes recepe = new Recepes();
		recepe.setRecepieName("DOSA");
		recepe.setCookingIntructions("No");
		recepe.setRecepieCreationDate(new Date());
		recepe.setSurvingPeople("100");
		Ingredients ingredients = new Ingredients();
		ingredients.setIngredents("CHATANI");
		List<Ingredients> indreIngredientsList = singletonList(ingredients);
		recepe.setRecIngredients(indreIngredientsList);
		// when
		recepesMgmtControllerService.save(recepe);
		// then
		assertNotNull(recepesMgmtControllerService.findAll());
	}

	@Test
	public void deleteRecepeIngredients() {
		// Given
		Recepes recepebase = new Recepes();
		recepebase.setRecepieName("DOSA");
		recepebase.setCookingIntructions("No");
		recepebase.setRecepieCreationDate(new Date());
		recepebase.setSurvingPeople("100");
		recepesMgmtControllerService.save(recepebase);

		// when
		recepesMgmtControllerService.deleteById(recepebase.getRecepieId());

		// then
		assertThat(recepebase.getRecepieName()).isEqualTo("DOSA");
	}
}
