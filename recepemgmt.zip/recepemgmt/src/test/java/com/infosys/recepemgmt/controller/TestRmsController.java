package com.infosys.recepemgmt.controller;

import java.util.Date;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.recepemgmt.bean.Ingredients;
import com.infosys.recepemgmt.bean.Recepes;
import com.infosys.recepemgmt.bean.RecepesMgmtResponseBean;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static java.util.Collections.singletonList;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.core.Is.is;
import static org.mockito.BDDMockito.given;

/**
 * 
 * @author SHARAD
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@WebMvcTest(RecepesManagementAPIController.class)
@Component
public class TestRmsController {

	@Autowired
	MockMvc mockMvc;
	@Autowired
	ObjectMapper mapper;

	@MockBean
	RecepesManagementAPIController recepesManagementAPIController;

	@Test
	public void getAllRecords_success() throws Exception {
		Recepes recepes = new Recepes();
		Ingredients indreIngredients = new Ingredients();
		indreIngredients.setIngredents("Dange");
		recepes.setRecepieName("Sharad");
		recepes.setRecepieCreationDate(new Date());
		recepes.setSurvingPeople("100");
		recepes.setCookingIntructions("Cooke Well");
		recepes.setIsVegeterian("Y");
		List<Ingredients> indreIngredientsList = singletonList(indreIngredients);
		recepes.setRecIngredients(indreIngredientsList);
		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		List<Recepes> allrecepes = singletonList(recepes);

		response.setRecepeList(allrecepes);

		given(recepesManagementAPIController.getAllRecepes()).willReturn(response);

		Mockito.when(recepesManagementAPIController.getAllRecepes()).thenReturn(response);

		mockMvc.perform(MockMvcRequestBuilders.get("/restapi/recepes").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[2].recepeName", is("Sharad")));
	}

}
