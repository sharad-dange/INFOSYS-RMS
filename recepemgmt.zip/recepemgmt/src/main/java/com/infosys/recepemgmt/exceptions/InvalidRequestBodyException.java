package com.infosys.recepemgmt.exceptions;

/**
 * This class is user defined InvalidRequestBodyException class
 * 
 * @author SHARAD
 *
 */
public class InvalidRequestBodyException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * @author SHARAD
	 * @param message
	 * @param cause
	 */
	public InvalidRequestBodyException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @author SHARAD
	 * @param message
	 */
	public InvalidRequestBodyException(String message) {
		super(message);
	}

	/**
	 * @author SHARAD
	 * @param cause
	 */
	public InvalidRequestBodyException(Throwable cause) {
		super(cause);
	}
}
