package com.infosys.recepemgmt.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.recepemgmt.bean.Recepes;
import com.infosys.recepemgmt.bean.RecepesMgmtResponseBean;
import com.infosys.recepemgmt.constants.RmsConstants;
import com.infosys.recepemgmt.exceptions.InvalidRecepeIDException;
import com.infosys.recepemgmt.exceptions.InvalidRequestBodyException;
import com.infosys.recepemgmt.processhelper.RecepesMgmtProcessAPIHelper;

/**
 * This is the rest controller class, which is responsible for Request handling
 * 
 * @author SHARAD
 *
 */

@RestController
@RequestMapping("/restapi")
public class RecepesManagementAPIController {

	private static final Logger logger = LogManager.getLogger(RecepesManagementAPIController.class);

	@Autowired
	RecepesMgmtProcessAPIHelper recepesMgmtProcessAPIHelper;

	/**
	 * This GetMapping Action "/recepes" used to return list of recepes
	 * 
	 * @author SHARAD
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */

	@GetMapping("/recepes")
	@ResponseBody
	public RecepesMgmtResponseBean getAllRecepes() {
		if (logger.isInfoEnabled())
			logger.info("Entered into getAllRecepes() method, Starting the operation now.");

		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.getAllRecepes();

		if (logger.isInfoEnabled())
			logger.info("Exited from getAllRecepes() method");

		return response;
	}

	/**
	 * This GetMapping Action "/recepes/{id}" used to return list of recepes based
	 * on recepe id
	 * 
	 * @author SHARAD
	 * @param recepeId
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */

	@GetMapping("/recepes/{recepeId}")
	@ResponseBody
	public RecepesMgmtResponseBean getRecepeByID(@PathVariable String recepeId) {

		if (logger.isInfoEnabled())
			logger.info("Entered into getRecepeByID() method, Starting the operation now. Request Data >> RECEPE_ID :"
					+ recepeId);
		int recipeId = -1;
		try {
			recipeId = Integer.parseInt(recepeId);
		} catch (Exception e) {
			logger.error("getRecepeByID(): Invalid recepeId : " + recepeId);
			throw new InvalidRecepeIDException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}

		if (0 > recipeId) {
			logger.error("getRecepeByID(): Invalid recepeId : " + recipeId);
			throw new InvalidRecepeIDException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}

		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.getRecepeFromID(recipeId);

		if (logger.isInfoEnabled())
			logger.info("Exited from getRecepeByID() method");

		return response;
	}

	/**
	 * This addRecepe() is used to create new recepe details using Recepe Request
	 * body
	 * 
	 * @author SHARAD
	 * @param recepesreq
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	@PostMapping("/recepes")
	@ResponseBody
	public RecepesMgmtResponseBean addRecepe(@RequestBody Recepes recepesreq) {

		if (logger.isInfoEnabled())
			logger.info("Entered into addRecepe() method, Starting the operation now");

		if (null == recepesreq) {
			logger.error("addRecepe(): Invalid Request Body observed");
			throw new InvalidRequestBodyException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}

		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();

		response = recepesMgmtProcessAPIHelper.validateCreateRequest(recepesreq);
		if (null != response && null != response.getResponseDesc() && !"".equalsIgnoreCase(response.getResponseDesc())
				&& response.getResponseDesc().startsWith(RmsConstants.RMS_ERROR)) {
			return response;
		}
		response = recepesMgmtProcessAPIHelper.createRecepe(recepesreq);

		if (logger.isInfoEnabled())
			logger.info("Exited from addRecepe() method");

		return response;
	}

	/**
	 * This updateRecepe() used to updated recepe using recepe id and Recepe request
	 * body
	 * 
	 * @author SHARAD
	 * @param recepeId
	 * @param recepesreq
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	@PutMapping("/recepes/{recepeId}")
	@ResponseBody
	public RecepesMgmtResponseBean updateRecepe(@PathVariable String recepeId, @RequestBody Recepes recepesreq) {
		if (logger.isInfoEnabled())
			logger.info("Entered into addRecepe() method, Starting the operation now");

		if (null == recepesreq) {
			logger.error("updateRecepe(): Invalid Request Body observed");
			throw new InvalidRequestBodyException(RmsConstants.ERR_INVALID_REQUEST_BODY);
		}

		int recipeId = -1;
		try {
			recipeId = Integer.parseInt(recepeId);
		} catch (Exception e) {
			logger.error("getRecepeByID(): Invalid recepeId : " + recepeId);
			throw new InvalidRecepeIDException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}

		if (0 >= recipeId) {
			logger.error("deleteEmployee(): Invalid recepeId : " + recepeId);
			throw new InvalidRecepeIDException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}

		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.validateUpdateRequest(recepesreq);
		if (null != response && null != response.getResponseDesc() && !"".equalsIgnoreCase(response.getResponseDesc())
				&& response.getResponseDesc().startsWith(RmsConstants.RMS_ERROR)) {
			return response;
		}
		response = recepesMgmtProcessAPIHelper.updateRecepe(recipeId, recepesreq);

		if (logger.isInfoEnabled())
			logger.info("Exited from updateRecepe() method");
		return response;
	}

	/**
	 * This deleteEmployee() used for delete the recepe based on request recepe id
	 * 
	 * @author SHARAD
	 * @param recepeId
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	@DeleteMapping("/recepes/{recepeId}")
	@ResponseBody
	public RecepesMgmtResponseBean deleteEmployee(@PathVariable String recepeId) {

		if (logger.isInfoEnabled())
			logger.info("Entered into deleteEmployee() method, Starting the operation now. Request Data >> RECEPE_ID :"
					+ recepeId);

		int recipeId = -1;
		try {
			recipeId = Integer.parseInt(recepeId);
		} catch (Exception e) {
			logger.error("getRecepeByID(): Invalid recepeId : " + recepeId);
			throw new InvalidRecepeIDException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}

		if (0 >= recipeId) {
			logger.error("deleteEmployee(): Invalid recepeId : " + recepeId);
			throw new InvalidRecepeIDException(RmsConstants.ERR_INVALID_RECEPE_ID);
		}

		RecepesMgmtResponseBean response = new RecepesMgmtResponseBean();
		response = recepesMgmtProcessAPIHelper.deleteRecepeByID(recipeId);

		if (logger.isInfoEnabled())
			logger.info("Exited from deleteEmployee() method");

		return response;
	}

}
