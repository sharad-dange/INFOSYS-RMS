package com.infosys.recepemgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.recepemgmt.bean.UserDataDO;

/**
 * This is the RecepeRepository which is responsible for getting databases
 * values from USER_CREDENTIALS table using JPA repository
 * 
 * @author SHARAD
 */

public interface UamUserRepository extends JpaRepository<UserDataDO, Long> {

	UserDataDO findByUsername(String username);

}
