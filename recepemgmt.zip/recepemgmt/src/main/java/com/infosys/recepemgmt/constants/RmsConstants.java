package com.infosys.recepemgmt.constants;

/**
 * This class contains all the constants which application needs
 * 
 * @author SHARAD
 *
 */
public class RmsConstants {

	public static final String RMS_SUCCESS = "SUCCESS";
	public static final String RMS_ERROR = "ERROR";
	public static final String RMS_COLUN = ":";

	public static final String RMS_RESPONSE_CODE_1000 = "1000";
	public static final String RMS_RESPONSE_CODE_0 = "0";
	public static final String RMS_RESPONSE_CODE_1001 = "1001";
	public static final String RMS_RESPONSE_CODE_1002 = "1002";
	public static final String RMS_RESPONSE_CODE_1003 = "1003";
	public static final String RMS_RESPONSE_CODE_1 = "1";
	public static final int RMS_UPDATE_ID = 0;
	public static final String RMS_RESPONSE_CODE_1004 = "1004";
	public static final String RMS_RESPONSE_CODE_1005 = "1005";
	public static final String RMS_RESPONSE_CODE_1006 = "1006";
	public static final String RMS_RESPONSE_CODE_1007 = "1007";
	public static final String RMS_RESPONSE_CODE_1008 = "1008";

	public static final String ERR_INVALID_RECEPE_ID = "Invalid Recepe Id";
	public static final String RMS_RECEPE_NOT_FOUND_1001 = "RECEPE NOT FOUND";
	public static final String RMS_REQ_PROCESS_FAILED = "Processing request Failed, Try after sometimes";
	public static final String ERR_INVALID_REQUEST_BODY = "Invalid Request Body";
	public static final String RMS_SUCCESS_RECEPE_RECEIVED = "Recepe Details have been successfully fetched";
	public static final String RMS_RECEPE_CREATED = "Recepe Details have been created successfully";
	public static final String RMS_RECEPE_CREATION_ERROR = "Not able to create Recepe";
	public static final String RMS_RECEPE_UPDATED = "Recepe Details have been updated successfully";
	public static final String RMS_RECEPE_UPDATED_NOT_FOUND = "Recepe Details Not found for update";
	public static final String RMS_RECEPE_DELETED = "Recepe Details have been deleted successfully";
	public static final String RMS_MANDATORY_ELEMENTS = "Please send mandotory paramters";
	public static final String RMS_RECEPE_NAME = "Recepe Name";
	public static final String RMS_INVALID_VEGETERIAN = "Please send valid vegeterian Parameter, it should be either 'N' or 'Y'";
	public static final String ERR_INVALID_NO_SURVING_PEOPLE = "Invalid No of surving people value";

}
