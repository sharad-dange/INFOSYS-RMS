package com.infosys.recepemgmt.exceptions;

/**
 * This class is user defined RecepeNotFoundException class
 * 
 * @author SHARAD
 *
 */
public class RecepeNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * @author SHARAD
	 * @param message
	 * @param cause
	 */
	public RecepeNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @author SHARAD
	 * @param message
	 */
	public RecepeNotFoundException(String message) {
		super(message);
	}

	/**
	 * @author SHARAD
	 * @param cause
	 */
	public RecepeNotFoundException(Throwable cause) {
		super(cause);
	}

}
