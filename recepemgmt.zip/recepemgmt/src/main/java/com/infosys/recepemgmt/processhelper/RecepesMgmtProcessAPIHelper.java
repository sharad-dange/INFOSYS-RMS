package com.infosys.recepemgmt.processhelper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.infosys.recepemgmt.bean.Ingredients;
import com.infosys.recepemgmt.bean.Recepes;
import com.infosys.recepemgmt.bean.RecepesMgmtResponseBean;
import com.infosys.recepemgmt.constants.RmsConstants;
import com.infosys.recepemgmt.exceptions.RecepeNotFoundException;
import com.infosys.recepemgmt.service.RecepesMgmtControllerService;

/**
 * This class is used for all the helper things like add, delete, update and get
 * operations
 * 
 * @author SHARAD
 *
 */
@Component
public class RecepesMgmtProcessAPIHelper {

	private static final Logger logger = LogManager.getLogger(RecepesMgmtProcessAPIHelper.class);
	private RecepesMgmtControllerService recepesMgmtControllerService;

	/**
	 * Constructor
	 * 
	 * @param theRecepesMgmtControllerService
	 */
	@Autowired
	public RecepesMgmtProcessAPIHelper(RecepesMgmtControllerService theRecepesMgmtControllerService) {
		recepesMgmtControllerService = theRecepesMgmtControllerService;
	}

	/**
	 * This method is used to get All recepes available
	 * 
	 * @author SHARAD
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	public RecepesMgmtResponseBean getAllRecepes() {
		RecepesMgmtResponseBean recepesMgmtResponseBean = new RecepesMgmtResponseBean();
		if (logger.isInfoEnabled())
			logger.info("Entered into getAllRecepes() Method");
		try {
			List<Recepes> recepeList = recepesMgmtControllerService.findAll();

			if (null == recepeList || recepeList.isEmpty() || recepeList.size() < 1) {
				throw new RecepeNotFoundException(RmsConstants.RMS_RECEPE_NOT_FOUND_1001);
			}

			recepesMgmtResponseBean.setRecepeList(recepeList);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_SUCCESS + RmsConstants.RMS_COLUN + RmsConstants.RMS_SUCCESS_RECEPE_RECEIVED);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_0);
		} catch (RecepeNotFoundException re) {
			logger.error("RecepeNotFoundException occured while getAllRecepes() :: ", re);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_RECEPE_NOT_FOUND_1001);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1001);
		} catch (Exception e) {
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_REQ_PROCESS_FAILED);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1);
			logger.error("Excepetion occured while getAllRecepes() :: ", e);
		}

		if (logger.isInfoEnabled())
			logger.info("Exited from getAllRecepes() Method");

		return recepesMgmtResponseBean;
	}

	/**
	 * This method is used to get Recepe Details using recepe ID
	 * 
	 * @author SHARAD
	 * @param recepeId
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	public RecepesMgmtResponseBean getRecepeFromID(int recepeId) {
		if (logger.isInfoEnabled())
			logger.info("Entered into getRecepeFromID() method, Starting the operation now, RECEPE_ID : " + recepeId);
		RecepesMgmtResponseBean recepesMgmtResponseBean = new RecepesMgmtResponseBean();
		try {

			Recepes recepe = recepesMgmtControllerService.findById(recepeId);
			if (null != recepe) {
				List<Recepes> recepeFianlList = new ArrayList<Recepes>();
				recepeFianlList.add(recepe);
				recepesMgmtResponseBean.setRecepeList(recepeFianlList);
				recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_0);
				recepesMgmtResponseBean.setResponseDesc(
						RmsConstants.RMS_SUCCESS + RmsConstants.RMS_COLUN + RmsConstants.RMS_SUCCESS_RECEPE_RECEIVED);
			} else {
				logger.error("No Recepes found for given RECEPE_ID : " + recepeId);
				throw new RecepeNotFoundException(RmsConstants.RMS_RECEPE_NOT_FOUND_1001);
			}
		} catch (RecepeNotFoundException re) {
			logger.error("RecepeNotFoundException occured while getRecepeFromID() :: ", re);
			recepesMgmtResponseBean.setResponseDesc(RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + re.getMessage());
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1001);
		} catch (RuntimeException runEx) {
			logger.error("RuntimeException occured while getRecepeFromID() :: ", runEx);
			recepesMgmtResponseBean
					.setResponseDesc(RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + runEx.getMessage());
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1001);
		} catch (Exception e) {
			logger.error("Exception occured while getRecepeFromID() :: ", e);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_REQ_PROCESS_FAILED);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1);
		}
		if (logger.isInfoEnabled())
			logger.info("Exited from getRecepeFromID() Method");
		return recepesMgmtResponseBean;
	}

	/**
	 * This method is used to create Recepe using request JSON body
	 * 
	 * @author SHARAD
	 * @param recepesMgmtRequestBean
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	public RecepesMgmtResponseBean createRecepe(Recepes recepesMgmtRequestBean) {

		if (logger.isInfoEnabled())
			logger.info("Entered into createRecepe() method, Starting the operation now");
		RecepesMgmtResponseBean recepesMgmtResponseBean = new RecepesMgmtResponseBean();
		try {

			Recepes recepes = new Recepes();
			recepes.setRecepieId(RmsConstants.RMS_UPDATE_ID);
			recepes.setRecepieCreationDate(new Date());
			recepes.setCookingIntructions(recepesMgmtRequestBean.getCookingIntructions());
			recepes.setIsVegeterian(recepesMgmtRequestBean.getIsVegeterian());
			recepes.setRecepieName(recepesMgmtRequestBean.getRecepieName());
			recepes.setSurvingPeople(recepesMgmtRequestBean.getSurvingPeople());
			recepes.setRecIngredients(recepesMgmtRequestBean.getRecIngredients());

			logger.info("Ingredients : " + recepesMgmtRequestBean.getRecIngredients());

			if (null != recepesMgmtRequestBean.getRecIngredients()
					&& !recepesMgmtRequestBean.getRecIngredients().isEmpty()
					&& recepesMgmtRequestBean.getRecIngredients().size() > 0) {
				for (Ingredients intgrends : recepesMgmtRequestBean.getRecIngredients()) {
					intgrends.setRecepes(recepes);
				}
			}

			recepesMgmtControllerService.save(recepes);

			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_0);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_SUCCESS + RmsConstants.RMS_COLUN + RmsConstants.RMS_RECEPE_CREATED);
		} catch (Exception e) {
			logger.error("Exception occured in createRecepe(), MESSAGE : ", e);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1004);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_RECEPE_CREATION_ERROR);
		}

		if (logger.isInfoEnabled())
			logger.info("Exited from createRecepe() method");

		return recepesMgmtResponseBean;

	}

	/**
	 * This method is used for update the existing Recepes using RecepeId and Recepe
	 * request body
	 * 
	 * @author SHARAD
	 * @param recepeId
	 * @param recepes
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	public RecepesMgmtResponseBean updateRecepe(int recepeId, Recepes recepes) {
		if (logger.isInfoEnabled())
			logger.info("Entered into updateRecepe() method, Starting the operation now, RECEPE_ID : " + recepeId);
		RecepesMgmtResponseBean recepesMgmtResponseBean = new RecepesMgmtResponseBean();
		try {

			Recepes recepe = recepesMgmtControllerService.findById(recepeId);

			if (null != recepe) {
				recepe.setRecepieId(recepeId);
				recepe.setCookingIntructions(recepes.getCookingIntructions());
				recepe.setIsVegeterian(recepes.getIsVegeterian());
				recepe.setSurvingPeople(recepes.getSurvingPeople());
				recepe.setRecIngredients(recepes.getRecIngredients());

				logger.info("Ingredients : " + recepes.getRecIngredients());

				if (null != recepes.getRecIngredients() && !recepes.getRecIngredients().isEmpty()
						&& recepes.getRecIngredients().size() > 0) {
					for (Ingredients intgrends : recepes.getRecIngredients()) {
						intgrends.setRecepes(recepe);
					}
				}

				recepesMgmtControllerService.save(recepe);

				recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_0);
				recepesMgmtResponseBean.setResponseDesc(
						RmsConstants.RMS_SUCCESS + RmsConstants.RMS_COLUN + RmsConstants.RMS_RECEPE_UPDATED);
			}
		} catch (RuntimeException ex) {
			logger.error("RunTimeException occured in updateRecepe(),:RecepeId:" + recepeId + " MESSAGE : ", ex);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1005);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_RECEPE_UPDATED_NOT_FOUND);
		} catch (Exception e) {
			logger.error("Exception occured in updateRecepe(), MESSAGE : ", e);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_REQ_PROCESS_FAILED);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1);
		}

		if (logger.isInfoEnabled())
			logger.info("Exited from updateRecepe() method");

		return recepesMgmtResponseBean;
	}

	/**
	 * This method is used to delete the Recepe by using RecepeId
	 * 
	 * @author SHARAD
	 * @param recepeId
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	public RecepesMgmtResponseBean deleteRecepeByID(int recepeId) {
		if (logger.isInfoEnabled())
			logger.info("Entered into deleteRecepeByID() method, Starting the operation now, RECEPE_ID : " + recepeId);
		RecepesMgmtResponseBean recepesMgmtResponseBean = new RecepesMgmtResponseBean();
		try {
			recepesMgmtControllerService.deleteById(recepeId);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_0);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_SUCCESS + RmsConstants.RMS_COLUN + RmsConstants.RMS_RECEPE_DELETED);
		} catch (RuntimeException runEx) {
			logger.error("RuntimeException occured while deleteRecepeByID() :: ", runEx);
			recepesMgmtResponseBean
					.setResponseDesc(RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + runEx.getMessage());
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1001);
		} catch (Exception e) {
			logger.error("Exception occured in deleteRecepeByID(), MESSAGE : ", e);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_REQ_PROCESS_FAILED);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1);
		}
		if (logger.isInfoEnabled())
			logger.info("Exited from deleteRecepeByID() method");
		return recepesMgmtResponseBean;
	}

	/**
	 * This method is used to validate the request parameters for create request
	 * 
	 * @param recepesMgmtRequestBean
	 * @return response as a response entity of RecepesMgmtResponseBean type
	 */
	public RecepesMgmtResponseBean validateCreateRequest(Recepes recepesMgmtRequestBean) {
		if (logger.isInfoEnabled())
			logger.info("Entered into validateCreateRequest() method, Starting the operation now");
		RecepesMgmtResponseBean recepesMgmtResponseBean = new RecepesMgmtResponseBean();

		try {

			if (null == recepesMgmtRequestBean.getRecepieName()
					|| "".equalsIgnoreCase(recepesMgmtRequestBean.getRecepieName())) {

				recepesMgmtResponseBean.setResponseDesc(RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN
						+ RmsConstants.RMS_MANDATORY_ELEMENTS + "," + RmsConstants.RMS_RECEPE_NAME);
				recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1006);
			}

			if (!"N".equals(recepesMgmtRequestBean.getIsVegeterian())
					&& !"Y".equals(recepesMgmtRequestBean.getIsVegeterian())) {

				recepesMgmtResponseBean.setResponseDesc(
						RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_INVALID_VEGETERIAN);
				recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1007);
			}

			if (null != recepesMgmtRequestBean.getSurvingPeople()
					&& !"".equalsIgnoreCase(recepesMgmtRequestBean.getSurvingPeople())) {

				try {
					int survingPeople = Integer.parseInt(recepesMgmtRequestBean.getSurvingPeople());
					logger.info("No of people suring : " + survingPeople);

					if (0 > survingPeople) {
						recepesMgmtResponseBean.setResponseDesc(RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN
								+ RmsConstants.ERR_INVALID_NO_SURVING_PEOPLE);
						recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1008);
					}
				} catch (Exception e) {
					logger.error("Exception occured in validateCreateRequest(), MESSAGE : ", e);
					recepesMgmtResponseBean.setResponseDesc(RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN
							+ RmsConstants.ERR_INVALID_NO_SURVING_PEOPLE);
					recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1008);
				}

			}

		} catch (Exception e) {
			logger.error("Exception occured in validateCreateRequest(), MESSAGE : ", e);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_REQ_PROCESS_FAILED);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1);
		}

		if (logger.isInfoEnabled())
			logger.info("Exited from validateCreateRequest() method");

		return recepesMgmtResponseBean;
	}

	public RecepesMgmtResponseBean validateUpdateRequest(Recepes recepesMgmtRequestBean) {
		if (logger.isInfoEnabled())
			logger.info("Entered into validateUpdateRequest() method, Starting the operation now");
		RecepesMgmtResponseBean recepesMgmtResponseBean = new RecepesMgmtResponseBean();

		try {

			if (!"N".equals(recepesMgmtRequestBean.getIsVegeterian())
					&& !"Y".equals(recepesMgmtRequestBean.getIsVegeterian())) {

				recepesMgmtResponseBean.setResponseDesc(
						RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_INVALID_VEGETERIAN);
				recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1007);
			}

			if (null != recepesMgmtRequestBean.getSurvingPeople()
					&& !"".equalsIgnoreCase(recepesMgmtRequestBean.getSurvingPeople())) {

				try {
					int survingPeople = Integer.parseInt(recepesMgmtRequestBean.getSurvingPeople());
					logger.info("No of people suring : " + survingPeople);

					if (0 > survingPeople) {
						recepesMgmtResponseBean.setResponseDesc(RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN
								+ RmsConstants.ERR_INVALID_NO_SURVING_PEOPLE);
						recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1008);
					}
				} catch (Exception e) {
					logger.error("Exception occured in validateUpdateRequest(), MESSAGE : ", e);
					recepesMgmtResponseBean.setResponseDesc(RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN
							+ RmsConstants.ERR_INVALID_NO_SURVING_PEOPLE);
					recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1008);
				}

			}

		} catch (Exception e) {
			logger.error("Exception occured in validateUpdateRequest(), MESSAGE : ", e);
			recepesMgmtResponseBean.setResponseDesc(
					RmsConstants.RMS_ERROR + RmsConstants.RMS_COLUN + RmsConstants.RMS_REQ_PROCESS_FAILED);
			recepesMgmtResponseBean.setResponseStatus(RmsConstants.RMS_RESPONSE_CODE_1);
		}

		if (logger.isInfoEnabled())
			logger.info("Exited from validateUpdateRequest() method");

		return recepesMgmtResponseBean;
	}
}
